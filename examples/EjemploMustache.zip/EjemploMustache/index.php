<?php

$biblioteca = simplexml_load_file('biblioteca.xml');

require 'Mustache/Autoloader.php';
Mustache_Autoloader::register();

$m = new Mustache_Engine(array(
'loader' => new Mustache_Loader_FilesystemLoader(dirname(__FILE__) .'/views')));
   

echo $m->render('header');

if(isset($_GET['list'])){ //CUANDO ES LISTADO

	echo $m->render('navPrincipal');

	if($_GET['list']="libros"){//CUANDO ES LISTADO DE LIBROS

		$lista="";
		foreach ($biblioteca->libros->libro as $libro) {
			$lista=$lista.'
			<tr>
				<td>'.$libro->nombre.'</td>
				<td>'.$libro->isbn.'</td>
				<td>'.$libro->fecha.'</td>
				<td>'.$libro->editorial.'</td>
				<td><a href="index.php?detalle=libro&id='.$libro->isbn.'">Ver detalle</a></td>
			</tr>
			';
		}

		$libros = array('lista' => $lista);
		echo $m->render('listLibros', $libros);
	}
	else{
		echo 'SITIO EN CONSTRUCCION...';
	}
}
elseif(isset($_GET['detalle']))//CUANDO ES DETALLE
{	

	if($_GET['detalle']=='libro'){//CUANDO ES EL DETALLE PARA UN LIBRO

		$resultado= $biblioteca->xpath('//libro[isbn='.$_GET['id'].']');
		
		foreach ($resultado as $value) {
				$libro = array('nombre' => $value->nombre,
				 				'fecha' => $value->fecha,
				 				'isbn' => $value->isbn,
				 				'paginas' => $value->paginas,
				 				'editorial' => $value->editorial);
		}

		$autores="";
		$resultado = $biblioteca->xpath('//autorXlibro[libro='.$_GET['id'].']');//OBTENGO COD AUTORES

		foreach ($resultado as $aXl) {
			$autor = $biblioteca->xpath('//autor[cod='.$aXl->autor.']');//OBTENGO INFO DE LOS AUTORES

			foreach ($autor as $a) {
				$autores = $autores.'<tr>
			<td>'.$a->nombre.'</td>
			<td>'.$a->apellido.'</td>
			<td>'.$a->edad.'</td>
			<td>'.$a->pais.'</td>
			<td><a href="index.php?detalle=autor&id='.$a->id.'">Ver detalle</a></td>
			</tr>';
			}
		}

		$libro['autores'] = $autores;
		
		echo $m->render('detalleLibro',$libro);
	}
	else
	{
		echo 'SITIO EN CONSTRUCCION...';
	}

}
else{//CUANDO NO ES DETALLE NI LISTADO

	echo $m->render('navPrincipal');
}

echo $m->render('footer');
?>