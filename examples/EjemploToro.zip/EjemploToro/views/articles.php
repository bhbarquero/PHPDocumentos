<h1>Blog</h1>

<?php
    foreach ($articles as $article) {
        include("_article.php");
    }
?>

<h4>Add Article</h4>
<form method="post" action="/article/new">
    <strong>Title:</strong><br/>
    <input type="text" name="title" /><br/>
    <strong>Slug:</strong><br/>
    <input type="text" name="slug" /><br/>
    <strong>Message:</strong><br/>
    <textarea name="body"></textarea><br/>
    <input type="submit" />
</form>