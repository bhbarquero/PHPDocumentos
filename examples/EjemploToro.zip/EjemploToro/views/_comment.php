<strong><?php echo $comment['name']; ?></strong> commented:
<div><?php echo Markdown($comment['body']); ?></div>
<hr />