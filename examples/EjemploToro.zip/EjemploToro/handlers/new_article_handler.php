<?php

class NewArticleHandler {
    function post() {

        if (isset($_POST['title']) && 
        	isset($_POST['body']) && 
        	isset($_POST['slug']) && 
            strlen(trim($_POST['title'])) > 0 &&
            strlen(trim($_POST['body'])) > 0 &&
            strlen(trim($_POST['slug'])) > 0 )
        {

            save_article(trim($_POST['title']), trim($_POST['slug']), trim($_POST['body']));
        }

        header("Location: /");
    }
}